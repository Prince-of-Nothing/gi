# GidiReads — Batch 1 & 2 implementation notes

## Homepage and discovery

- Hero story selection remains manually curated in Admin → Homepage & Explore Manager. The homepage does not substitute an automatically popular story when no hero is selected.
- Featured for You remains manually curated through the existing Featured manager and its saved order.
- Trending Now is automatic and uses the novel-ranking calculation described below.
- Recently Updated is automatic and orders stories by the latest publication/update timestamp among published, non-archived chapters. Editing a story description, cover, or other metadata does not make it appear newly updated.
- New Releases is automatic and orders stories by their first publication timestamp, with a published-chapter timestamp fallback for older records.
- Automatic shelves exclude draft stories and require at least one published, non-archived chapter.
- Homepage story cards show published chapter count, Echoes and Reads. Draft and archived chapters are excluded from the chapter count.
- Explore and collection “See all” pages use the same automatic ordering for Trending, Recently Updated and New Releases.

## Novel Rankings and Readerboard

- Rankings is available from the primary navigation. Novel rankings are displayed vertically, with position, cover, title, author, genre and story status.
- The top three positions receive distinct crown/glow treatments.
- Novel Rankings and Readerboard support Weekly (rolling 7 days), Monthly (rolling 30 days), 90 days, 180 days and All time.
- Result depth supports Top 100, Top 200 and Top 500, loaded in 50-row pages.
- Each novel receives **one combined score** from Reads, Echoes, Collections and Reviews. Each metric contributes up to 25 points after normalization against the highest value for that metric among eligible novels in the selected period. The maximum score is 100. The same formula and weights apply to every period; only the date window changes.
- Published chapter count is displayed for information and does not affect the novel score. Novel cards show lifetime totals for Reads, Echoes, Collections and Reviews alongside the combined score for the selected period.
- Readerboard scoring is unchanged: verified completed chapters × 10 + qualifying reading days × 2 + current streak days × 3 + verified completed novels × 5. Reading days are based on qualifying sessions on published chapters. A user does not earn novel ranking activity by engaging with their own story.

## Metric definitions

- **Reads:** timestamped `story_opened` events for selected periods. All time uses the existing `stories.reads` counter so older reads are not lost.
- **Echoes:** external chapter Echo records plus the summed amounts of chapterless Echo support events. Author self-Echoes are excluded.
- **Collections:** distinct readers who added a novel to a personal reading list or the main Library during the selected period. A reader counts once per novel even if the novel is saved in multiple places.
- **Reviews:** external reviews created during the selected period. Author self-reviews are excluded.

## Production database migrations

The project includes the following Batch 1 & 2 migrations. The four-metric ranking migrations are listed last.

1. `20261108200000_homepage_discovery_and_rankings.sql`
2. `20261108201000_fix_novel_rankings_echo_join.sql`
3. `20261108202000_readerboard_verified_novel_completion.sql`
4. `20261108203000_readerboard_session_based_consistency.sql`
5. `20261108204000_readerboard_chapter_first_scoring.sql`
6. `20261108205000_exclude_author_self_activity_from_rankings.sql`
7. `20261108206000_secure_public_rankings_rpc_wrappers.sql`
8. `20261108210000_fix_latest_published_chapter_timestamp.sql`
9. `20261109090000_reconcile_novel_ranking_metrics_and_weighted_score.sql`
10. `20261109153000_novel_rankings_four_metric_engagement_score.sql`
11. `20261109154500_include_library_entry_period_collections.sql`

The public RPC wrappers use invoker security; aggregate implementations are kept in the non-exposed `private` schema. The final collections migration ensures main-Library entries are filtered to the selected period, rather than being counted as lifetime activity in shorter periods.

## Release and validation notes

- This package is based on the exact user-supplied `GidiReads-Launch-2-Batch-4-3.zip`. Its original project files are retained; the Rankings page assets and Batch 1 & 2 documentation are updated, and the required ranking migrations are included.
- Production database migrations were applied separately to the connected GidiReads Supabase project. The ZIP itself does not deploy or apply database changes.
- The frontend has not been deployed. Deploy this complete ZIP only after reviewing the checks below and confirming the target Vercel project.
- Payments and payouts remain disabled. No payment provider or payout functionality is enabled by this work.
- Automated static checks are recorded in the accompanying release notes. Browser-based authenticated end-to-end testing was not performed.
