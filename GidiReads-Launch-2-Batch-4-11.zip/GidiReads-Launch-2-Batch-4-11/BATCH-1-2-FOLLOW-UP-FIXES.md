# Batch 1–2 follow-up corrections

- Recently Updated now uses the greatest available timestamp among each published chapter's `updated_at`, `published_at`, and `created_at`, so a later publication timestamp cannot be hidden by an earlier update timestamp.
- New Releases remains ordered by the novel's first publication timestamp (falling back to its first published chapter timestamp).
- Rankings now display published chapter count, lifetime reads, and lifetime Echoes directly beneath the cover/title details, alongside ongoing/completed status and primary genre.
- Removed the visible ranking-score explanation. The selected period still determines ranking position; the score formula is not shown in the interface.
- Ranking order continues to use verified activity for the selected period. Displayed story totals are lifetime counters and are labelled Chapters, Reads, and Echoes.

The `gidireads_homepage_shelf` timestamp correction was applied to the production Supabase project in migration `20261108210000_fix_latest_published_chapter_timestamp.sql`.
