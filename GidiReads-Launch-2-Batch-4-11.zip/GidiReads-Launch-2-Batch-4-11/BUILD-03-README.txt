GIDIREADS BUILD 03 HOTFIX — CONTRACT CENTER + CREATOR EARNINGS

WHAT THIS ZIP CONTAINS
- authors-studio.html (updated): Contract Center and Creator Earnings now have working links in the Authors Studio sidebar and shortcut section.
- contract-center.html / .js: author contract application and application history.
- creator-earnings.html / .js: creator earnings ledger and payout request page.
- admin.html and admin-economy.html / .js: admin pages for the Build 03 economy and contract workflows.
- my-gidireads.html / .js / .css: My GidiReads integration.
- creator-economy.css: shared feature styling.
- GIDIREADS-BUILD-03-REQUIRED-SUPABASE-MIGRATION.sql: required database schema and RPC functions for the features.

WHY APPLICATION SUBMISSION IS FAILING
The current GidiReads production database was inspected read-only. It does not currently contain the Build 03 contract tables (including public.contract_applications), and its migration history does not include this feature migration. The front-end calls public.submit_contract_application(...), but that RPC function is created by the SQL migration. Uploading HTML/JS to Netlify or Acode does not create the database tables/functions.

INSTALL ORDER
1. Make a backup of your current site files and database before applying any production migration.
2. In Acode, extract this ZIP and copy the included files into the root of your website, replacing files with the same names. Do not delete unrelated files or folders. This is a patch, not the whole website.
3. IMPORTANT: The SQL file is NOT uploaded/run by Acode or Netlify. It must be reviewed and run in Supabase SQL Editor for the GidiReads project before contract submission and earnings features can work.
4. Do not run the SQL on an unknown project. It assumes the existing GidiReads core schema (profiles, stories, chapters, notifications) is present. It adds the Build 03 economy and contract features. The migration has not been executed by this package and does not send payments or transfer money.
5. After the SQL succeeds, reload the site and test with a non-admin author account. If the schema-cache error persists, wait briefly, reload, and check the Supabase Logs/SQL Editor for any migration error before retrying.

SAFETY / LIMITATIONS
- No payment provider or webhook is configured. Payout requests are records for admin processing, not bank transfers.
- Earnings only appear when trusted backend processes create ledger entries; views/reads do not automatically create money.
- Gift catalogue entries remain inactive.
- The SQL migration has not been executed or end-to-end tested in this package. Do not treat this as a verified production release.
