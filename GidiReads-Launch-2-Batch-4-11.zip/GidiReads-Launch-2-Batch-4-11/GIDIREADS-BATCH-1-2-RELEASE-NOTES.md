# GidiReads Batch 1 & 2 — deployment package

This complete project package is based on the user-supplied `GidiReads-Launch-2-Batch-4-3.zip`. It retains that archive's project files and includes the four-metric novel-ranking frontend, the required ranking SQL migrations, and corrected Batch 1 & 2 documentation.

See `BATCH-1-2-HOMEPAGE-DISCOVERY-RANKINGS.md` for the exact feature scope, ranking formula, metric definitions and migration list.

## Deployment status

- Supabase migrations were applied separately to the connected GidiReads production project. Uploading this ZIP does not apply SQL migrations.
- The frontend has **not** been deployed. This ZIP is the frontend project package for deployment.
- Payments and payouts remain disabled.
- Static validation was run on this package. Authenticated browser end-to-end testing was not performed, so a post-deployment smoke test is still required.
