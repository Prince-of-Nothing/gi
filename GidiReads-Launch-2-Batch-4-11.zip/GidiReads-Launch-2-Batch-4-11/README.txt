GidiReads Reader V2
====================

Files:
- reader.html
- reader.css
- reader.js

Keep your existing:
- supabaseClient.js

Folder:
Put all four files in the same folder.

Reader URL:
reader.html?story=STORY_ID

Optional:
reader.html?story=STORY_ID&chapterId=CHAPTER_ID
reader.html?story=STORY_ID&chapter=2
reader.html?story=STORY_ID&source=explore

Important:
This version does not depend on analytics succeeding before the manuscript can render.
It dynamically loads supabaseClient.js and shows a visible error if that file cannot load.
