GIDIREADS — WELCOME / ACCOUNT / TOUR BUILD 02

SMALL PATCH. No database changes. Do not replace supabaseClient.js.

Files included are only the welcome/auth integration files and the small homepage entry-point changes. Keep all other project files as they are.

Corrections in this pass:
- Hero story uses Admin Dashboard > Homepage Hero story_id; when none is selected or the selected story is unavailable, it uses the same popular-story fallback as the existing homepage.
- Featured cover is above the title, synopsis, and Read Now button.
- Reader/Author combination is stored as two roles, not a literal reader_author role.
- Publish signup entry preselects Author.
- Email-confirmation feedback is shown after page initialisation instead of being cleared.
- A selected profile photo is resized and preserved locally through email confirmation, then uploaded after the user signs in. If upload permissions fail, the user can still continue and upload from Account settings.
- Existing auth backend and supabaseClient.js are not changed.
- Creator role options remain disabled.

Before copying: back up only index.html and app.js (the two existing homepage files changed by this patch). Overwrite only files with matching names. No SQL.

Validation performed: JavaScript syntax check, HTML parsing, ZIP integrity, and source-level checks for Hero fallback, role mapping, confirmation notice order, and profile-photo persistence. This is not a live Supabase or device/browser end-to-end test. Test in Acode Preview before deployment.
