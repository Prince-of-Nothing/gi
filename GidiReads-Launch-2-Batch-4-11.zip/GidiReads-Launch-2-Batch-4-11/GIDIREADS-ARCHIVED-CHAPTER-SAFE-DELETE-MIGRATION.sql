-- GidiReads: permit permanent deletion of archived chapters only when no dependent reader or wallet records exist.
-- This migration adds a guarded RPC; it does not delete or modify existing chapter rows.
create or replace function public.gidireads_delete_archived_chapter_without_history(p_chapter_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_author_id uuid;
  v_archived_at timestamptz;
  v_ever_published_at timestamptz;
  v_history_known boolean;
begin
  if auth.uid() is null then
    raise exception 'Authentication is required.' using errcode = '42501';
  end if;

  select s.author_id, c.archived_at, c.ever_published_at, c.publication_history_known
    into v_author_id, v_archived_at, v_ever_published_at, v_history_known
  from public.chapters c
  join public.stories s on s.id = c.story_id
  where c.id = p_chapter_id;

  if not found or v_author_id is distinct from auth.uid() then
    raise exception 'This chapter is not available in your author account.' using errcode = '42501';
  end if;

  if v_archived_at is null or v_ever_published_at is null or v_history_known is not true then
    raise exception 'Only archived chapters with verified publication history can be permanently deleted.' using errcode = '55000';
  end if;

  if exists (select 1 from public.comments where chapter_id = p_chapter_id)
     or exists (select 1 from public.echo_support_events where chapter_id = p_chapter_id)
     or exists (select 1 from public.echoes where chapter_id = p_chapter_id)
     or exists (select 1 from public.notifications where chapter_id = p_chapter_id)
     or exists (select 1 from public.reading_bookmarks where chapter_id = p_chapter_id)
     or exists (select 1 from public.reading_events where chapter_id = p_chapter_id)
     or exists (select 1 from public.reading_progress where chapter_id = p_chapter_id)
     or exists (select 1 from public.reading_sessions where chapter_id = p_chapter_id)
     or exists (select 1 from public.user_completed_chapters where chapter_id = p_chapter_id)
     or exists (select 1 from public.wallet_chapter_pricing where chapter_id = p_chapter_id)
     or exists (select 1 from public.wallet_chapter_unlocks where chapter_id = p_chapter_id) then
    raise exception 'This archived chapter still has linked reader or wallet history. Keep it archived to preserve those records.' using errcode = '23503';
  end if;

  delete from public.chapters where id = p_chapter_id;
end;
$$;

revoke all on function public.gidireads_delete_archived_chapter_without_history(uuid) from public, anon;
grant execute on function public.gidireads_delete_archived_chapter_without_history(uuid) to authenticated;
