GIDIREADS COORDINATED PATCH — OPPORTUNITIES / HOLIDAY HEARTS / ECHOES / GIFTS / ADMIN

This is a patch, not a replacement for the full project. Back up each target file before copying.

INCLUDED FRONTEND FILES
- opportunities.html, opportunities.js, opportunities.css
- opportunities-admin.js, admin-dashboard.css
- store.html, store.js, store.css
- reader.html, reader.js, reader.css
- index.html, style.css
- create-story.html, create-story-step1.js, create-story-step1.css

ALL FIVE EXISTING OPPORTUNITY IMAGES
- assets/opportunities/holiday-hearts-main.jpg
- assets/opportunities/holiday-hearts-contest.jpg
- assets/opportunities/snowed-in.jpg
- assets/opportunities/one-last-christmas.jpg
- assets/opportunities/royal-holiday.jpg

The uploaded project stored these under assets/Opportunities (capital O). This patch uses the requested lowercase assets/opportunities path and includes all five files. Copy the folder as shown; do not mix casing on case-sensitive hosting.

DATABASE
- DEV-ONLY-OPPORTUNITIES-GIFTS-MIGRATION.sql
- DEV-ONLY-ECHO-SUPPORT-MIGRATION.sql
Run only against the development Supabase project after reviewing. Do not run in production. Back up development first.

SCOPE
Opportunities/contest UI and submission flow; contest admin review UI; Create Story contest handoff; Gift Store recipient lookup UI; Echo amount/scope support UI and server-side support event migration; admin dashboard styling; five contest images. Real-money purchases/payouts remain disabled.

VALIDATION STATUS
The package ZIP integrity, JavaScript syntax, HTML parsing, and image presence/path checks were run locally. These checks do not simulate signed-in Supabase sessions. Before production use, run the SQL in development and test with separate reader/author/admin accounts: contest submission and one-entry enforcement; voting window and self-vote rejection; gift recipient suggestions and wallet ledger; Echo balance deduction, repeat Echo events, and story/chapter totals. Do not deploy to production until those authenticated integration tests pass.
