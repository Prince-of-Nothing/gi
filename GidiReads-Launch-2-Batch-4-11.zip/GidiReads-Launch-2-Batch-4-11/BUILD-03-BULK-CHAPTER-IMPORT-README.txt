GIDIREADS V5 — BUILD 3: BULK CHAPTER IMPORT

WHAT CHANGED
- Added Bulk Chapter Import inside each author's Story Workspace.
- Authors can select multiple DOCX, TXT or Markdown files, or paste a manuscript containing several chapters.
- DOCX text is read in the browser with Mammoth.js loaded from its public CDN when needed. An internet connection is required for the first DOCX read.
- Chapter headings recognised include Chapter 1, Chapter Two, Part 1, Prologue, Epilogue, Afterword, Preface, Interlude and Markdown headings (# Title).
- A line containing three or more dashes, asterisks or equals signs can separate chapters.
- Authors can review and rename chapters, preview their text, reorder them, remove them and exclude items before saving.
- Exact duplicate chapter text already in the story or repeated in the current import is flagged and skipped.
- Each accepted chapter is saved as an unpublished draft. Existing chapters are never updated or replaced.
- An import report lists saved chapters and any failures. Failed items remain available for another attempt after a partial import.

SAFETY / DATA BEHAVIOUR
- The import is scoped to the story in the current workspace and checks that the signed-in user owns that story.
- Existing chapter order and numbering are read before saving. New chapter numbers and display order continue after the current maximum.
- No SQL migration is included or required by this front-end build.
- No Supabase database was changed and no migration was applied.
- No chapters are published automatically.

LIMITS
- Maximum 10 MB per file.
- Maximum 100 chapters in one import batch.
- Supported formats: .docx, .txt, .md and .markdown.
- Legacy .doc files and direct Google Drive connections are not supported. Text-based PDF files are supported; scanned/image-only PDFs need OCR or conversion before import. Google Docs users can download/export as .docx first.
- DOCX extraction requires internet access to load Mammoth.js from cdnjs. TXT and Markdown import work without that library.
- The chapter splitter relies on clear heading lines or separator lines. Authors should review the preview carefully before saving.

FILES
- story-workspace.html — import panel and entry point.
- story-workspace.css — responsive import styling.
- bulk-chapter-import.js — file reading, splitting, duplicate checks, preview and draft saving.

TESTS PERFORMED
- JavaScript syntax checks passed for the new module and existing Story Workspace module.
- HTML parsing passed for story-workspace.html.
- Static checks confirmed all import controls and the module script are present.
- ZIP integrity and complete-package checks are recorded in the accompanying build handoff.

NOT YET TESTED
- Authenticated end-to-end imports against the live Supabase project.
- DOCX browser extraction on a deployed Vercel domain and real Android devices.
- These checks require the user's approved V5 deployment and are intentionally deferred until then.


PDF SUPPORT UPDATE — 3 NOVEMBER 2026
- Added text-based PDF extraction using PDF.js 3.11.174 loaded from cdnjs.
- Reconstructs selectable text into lines in approximate reading order before chapter splitting.
- Supports up to 10 MB per file and 500 PDF pages per file.
- Password-protected, damaged and image-only/scanned PDFs receive a clear message. OCR is not claimed or silently attempted. A short but genuinely text-based PDF is not rejected just because it contains fewer than 40 characters.
- Extracted content still goes through the same chapter preview, title correction, duplicate check and draft-only save flow.
- Existing chapters are not replaced and no chapters are auto-published.


VERIFICATION UPDATE — 3 NOVEMBER 2026
- Ran automated chapter-splitting checks for numbered headings, Markdown headings, separator-only manuscripts, prologue/epilogue headings and unheaded text; all passed.
- Generated a two-page text PDF and confirmed the extracted text contains both chapter headings and body text using the local PDF text inspection utility.
- Generated an image-only/scanned-style PDF and confirmed it yields no selectable text in the local PDF text inspection utility.
- Checked the import module syntax after the short-PDF detection adjustment.
- The deployed browser PDF.js CDN loader and authenticated Supabase draft-save flow could not be exercised in this offline source workspace. Those remain deployment-stage checks; no live database writes were attempted.


Google Docs Picker update (5 Nov 2026): The Google Docs integration now uses Google Picker and the drive.file scope. Add the restricted browser API key to google-docs-config.js as described in GOOGLE-DOCS-TABS-SETUP.md. Each selected named tab becomes exactly one draft; a pasted tab-specific URL limits the loaded tab after the writer selects the matching document in Picker.
