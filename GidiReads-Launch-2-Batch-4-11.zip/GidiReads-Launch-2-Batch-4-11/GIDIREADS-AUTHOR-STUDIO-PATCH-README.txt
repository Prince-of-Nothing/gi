GidiReads Author Studio patch — 17 October 2026

Includes only files changed for this update:
- Story Bible and Author Notes now read/write through Supabase.
- Existing browser-local Story Bible entries and Author Notes are imported when their IDs are not already in the database. The browser copy is retained as a backup mirror.
- Supabase tables use Row Level Security and only allow the signed-in author to manage entries for stories they own.
- Adds two selectable profile headers: Vesper — The Frostkeeper and Nyx — The Night Familiar.
- The two image assets are included under assets/profile-headers/.

Installation:
1. Back up your development folder.
2. Extract this ZIP into the root of your GidiReads project folder, keeping the folders as shown and replacing matching files.
3. The database tables and policies have already been created in the connected GidiReads Supabase project. Do not rerun the SQL manually for this update; the SQL file is included as a record of the schema.
4. Test on the development site before deploying.

Test checklist:
- Sign in and open Story Bible from a story workspace. Add, edit, and delete an entry; reload the page.
- Repeat in Author Notes.
- If you had older browser-only notes, check that they appear and that the page reports that it is synced to your GidiReads account.
- Open Account/Profile, select each new header, save, and confirm it appears on the public author profile.
- To test cross-device sync, sign into the same account on another browser/device and open the same story workspace.

Important:
- Story Bible and Author Notes now store entries in Supabase; they are no longer limited to the current browser.
- Do not remove the original local browser data until you have confirmed that your existing entries have transferred successfully.
