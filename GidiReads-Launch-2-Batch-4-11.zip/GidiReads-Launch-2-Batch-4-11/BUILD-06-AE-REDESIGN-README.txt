GIDIREADS BUILD 6 — AE APPLICATION, WORKSPACE & RESOURCES VISUAL REFRESH

WHAT CHANGED
- AE application page now shows a clear submitted / in-review / approved / rejected state.
- Approved applicants see the exact role title, admin-entered contract dates, workspace link, and a clear explanation of the planned bonus programme.
- Bonus copy deliberately lists no rates or amounts and does not promise a salary or guaranteed payment. It explains that monetisation is planned after an initial 2–3-month period and that final rules will be communicated later.
- AE workspace has a refreshed hero, role/appointment summary, improved typography, spacing, plum/violet/ice-blue accents, and a bonus information panel in Performance.
- Admin AE application cards now allow admins to set contract start/end dates for approved AEs.
- AE application submission and status changes create in-app notifications. Saving contract dates also notifies the AE.
- Resources page uses the three supplied illustrations in a visual guide strip.

IMAGE FILES — ALREADY INCLUDED IN THIS PACKAGE
1. assets/ae/ae-editor-hero.jpg
2. assets/resources/resources-welcome.jpg
3. assets/resources/resources-guidance.jpg
4. assets/resources/resources-community.jpg

No need to create these files manually; they are already in the ZIP. If replacing them later, keep these exact names and paths.

DATABASE
After deploying this website package, apply:
1. BUILD-06-AE-APPLICATION-NOTIFICATIONS-MIGRATION.sql

Prerequisite: Build 4 AE migration has already been applied, as in the current GidiReads build sequence.
This migration adds nullable contract dates, in-app notification triggers for AE application submission/status changes, and an admin-only RPC to save approved AE contract dates.

NOT DONE / NOT CLAIMED
- No live Supabase migration was applied.
- No Vercel deployment was performed.
- No live browser/authenticated role test was possible in this package build.
- Browser push delivery depends on the existing push subscription and server-side push setup; this migration directly connects AE events to the in-app notifications table.

CHECKS PERFORMED
- JavaScript syntax checks for ae.js, ae-apply.js and admin.js.
- ZIP integrity check after packaging.
