GidiReads Authors Studio — Workspace Connection Fix

This patch corrects the previous workspace update.

WHAT CHANGED
- Removed the Story Bible, Author Notes, and Story Metadata shortcut cards from Authors Studio Home. Their links remain in the sidebar navigation.
- Connected the Story Workspace's Story Bible, Author Notes, and Story Metadata doors to their real pages.
- Each door passes the currently open story ID in the URL.
- The destination page validates that the selected story belongs to the signed-in author, then selects it automatically.
- Switching the story selector updates the current page URL and carries that story context through the workspace navigation.
- All five supplied character images are included. The ice-themed and cat companions are also visible in the workspaces' sidebar artwork.
- Story Bible and Author Notes remain browser-local storage for now, scoped by signed-in user and story. They do not sync across devices yet.
- Story Metadata saves to the existing stories table, subject to current Supabase RLS policies.

INSTALLATION
1. Back up your development project first.
2. Extract this ZIP.
3. Copy the included files into the same project root as your existing authors-studio.html, story-workspace.html, and supabaseClient.js, allowing the matching files to be replaced.
4. Preserve the assets/author-studio-characters/ directory and all five images.
5. Test in your development copy before deploying. No database schema changes or live deployment were made.

FILES INCLUDED
- authors-studio.html (updated: removed three Home shortcuts, kept navigation links)
- story-workspace.html, story-workspace.js, story-workspace.css (connected workspace doors)
- story-bible.html / story-bible.js
- author-notes.html / author-notes.js
- story-metadata.html / story-metadata.js
- studio-workspaces.css / studio-workspaces-common.js
- assets/author-studio-characters/ (five character images)

TEST CHECKLIST
1. Open an existing story from My Stories and enter its Story Workspace.
2. Click Story Bible, Author Notes, and Story Metadata. Each page should automatically select that same story.
3. Add a Story Bible entry and an Author Note, refresh, and verify they remain for that story in the same browser.
4. Switch to another story in the selector and verify the notes and Story Bible entries change with the selected story.
5. Edit metadata and save; verify the existing story record updates.
6. Confirm the Authors Studio Home no longer has separate shortcut cards for these three workspaces, while the sidebar navigation links remain.
7. Confirm all five character images load on their intended pages/sidebars.
