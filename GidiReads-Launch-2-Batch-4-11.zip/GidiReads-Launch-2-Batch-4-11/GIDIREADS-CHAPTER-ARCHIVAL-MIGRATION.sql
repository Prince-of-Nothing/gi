-- GidiReads Batch 2 / Phase 1: protected chapter deletion and archival.
-- Idempotent schema and policy migration. Already applied to the GidiReads production project.
-- Existing unpublished rows are marked as publication-history-unknown, not assumed to be safe to delete.

begin;

alter table public.chapters
  add column if not exists archived_at timestamptz,
  add column if not exists archived_by uuid references auth.users(id) on delete set null,
  add column if not exists ever_published_at timestamptz,
  add column if not exists publication_history_known boolean not null default false;

-- Existing live chapters are definitely known to have been published.
update public.chapters
set ever_published_at = coalesce(ever_published_at, published_at, created_at, now()),
    publication_history_known = true
where is_published = true;

-- Some older chapters are currently unpublished but still have reader activity.
-- Those linked records are evidence that the chapter was previously public.
update public.chapters c
set ever_published_at = coalesce(c.ever_published_at, c.created_at, now()),
    publication_history_known = true
where c.is_published = false
  and c.ever_published_at is null
  and (
    exists (select 1 from public.comments x where x.chapter_id = c.id)
    or exists (select 1 from public.echoes x where x.chapter_id = c.id)
    or exists (select 1 from public.echo_support_events x where x.chapter_id = c.id)
    or exists (select 1 from public.notifications x where x.chapter_id = c.id)
    or exists (select 1 from public.reading_bookmarks x where x.chapter_id = c.id)
    or exists (select 1 from public.reading_events x where x.chapter_id = c.id)
    or exists (select 1 from public.reading_progress x where x.chapter_id = c.id)
    or exists (select 1 from public.reading_sessions x where x.chapter_id = c.id)
    or exists (select 1 from public.user_completed_chapters x where x.chapter_id = c.id)
  );

-- Existing unpublished rows without proof remain history-unknown. This deliberately protects
-- chapters that may have been published and later unpublished before this migration.
alter table public.chapters
  alter column publication_history_known set default true;

create or replace function public.gidireads_track_chapter_publication_history()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if tg_op = 'INSERT' then
    new.publication_history_known := true;
    new.archived_at := null;
    new.archived_by := null;
    if new.is_published then
      new.ever_published_at := coalesce(new.ever_published_at, now());
    else
      new.ever_published_at := null;
    end if;
  else
    if old.ever_published_at is not null then
      new.ever_published_at := old.ever_published_at;
      new.publication_history_known := true;
    elsif new.is_published then
      new.ever_published_at := coalesce(new.ever_published_at, now());
      new.publication_history_known := true;
    elsif old.publication_history_known = false and current_user not in ('postgres', 'service_role') then
      -- Do not let an author relabel a legacy, unknown-history row as a safe draft.
      new.publication_history_known := false;
      new.ever_published_at := null;
    end if;
    if old.archived_at is distinct from new.archived_at
       or old.archived_by is distinct from new.archived_by then
      if current_user not in ('postgres', 'service_role') then
        raise exception 'chapter_archive_requires_authorized_action';
      end if;
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_gidireads_chapter_publication_history on public.chapters;
create trigger trg_gidireads_chapter_publication_history
before insert or update on public.chapters
for each row execute function public.gidireads_track_chapter_publication_history();

-- Preserve the original public policy semantics while excluding archived chapters.
drop policy if exists "Published chapters are publicly readable" on public.chapters;
create policy "Published chapters are publicly readable"
on public.chapters for select
using (
  (is_published = true and archived_at is null)
  or exists (
    select 1 from public.stories s
    where s.id = chapters.story_id and s.author_id = auth.uid()
  )
);

-- Consolidate the prior author/admin UPDATE policies without changing their effective access.
drop policy if exists "Admins can update any chapter" on public.chapters;
drop policy if exists "Authors can update chapters for their own stories" on public.chapters;
create policy "Authors and admins can update chapters"
on public.chapters for update
using (
  exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'admin')
  or exists (select 1 from public.stories s where s.id = chapters.story_id and s.author_id = (select auth.uid()))
)
with check (
  exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'admin')
  or exists (select 1 from public.stories s where s.id = chapters.story_id and s.author_id = (select auth.uid()))
);

-- Hard deletion is limited to newly-created rows whose publication history is known
-- and which have never been published. Legacy unpublished rows are protected.
drop policy if exists "Authors can delete chapters for their own stories" on public.chapters;
create policy "Authors can delete never-published chapters for their own stories"
on public.chapters for delete
using (
  publication_history_known = true
  and ever_published_at is null
  and archived_at is null
  and exists (
    select 1 from public.stories s
    where s.id = chapters.story_id and s.author_id = auth.uid()
  )
);

create or replace function public.gidireads_archive_chapter(p_chapter_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare v_user uuid := auth.uid(); v_chapter public.chapters%rowtype;
begin
  if v_user is null then raise exception 'authentication_required'; end if;
  select c.* into v_chapter
  from public.chapters c join public.stories s on s.id = c.story_id
  where c.id = p_chapter_id and s.author_id = v_user
  for update of c;
  if not found then raise exception 'chapter_not_owned'; end if;
  if v_chapter.ever_published_at is null then
    raise exception 'chapter_never_published_use_delete';
  end if;
  if v_chapter.archived_at is not null then
    return jsonb_build_object('success', true, 'already_archived', true);
  end if;
  update public.chapters
  set archived_at = now(), archived_by = v_user, is_published = false, updated_at = now()
  where id = p_chapter_id;
  return jsonb_build_object('success', true, 'archived', true);
end;
$$;

create or replace function public.gidireads_restore_archived_chapter(p_chapter_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare v_user uuid := auth.uid();
begin
  if v_user is null then raise exception 'authentication_required'; end if;
  update public.chapters c
  set archived_at = null, archived_by = null, is_published = false, updated_at = now()
  from public.stories s
  where c.id = p_chapter_id and c.story_id = s.id and s.author_id = v_user
    and c.archived_at is not null;
  if not found then raise exception 'archived_chapter_not_found_or_not_owned'; end if;
  return jsonb_build_object('success', true, 'restored', true, 'published', false);
end;
$$;

create or replace function public.gidireads_delete_never_published_chapter(p_chapter_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare v_user uuid := auth.uid();
begin
  if v_user is null then raise exception 'authentication_required'; end if;
  delete from public.chapters c
  using public.stories s
  where c.id = p_chapter_id and c.story_id = s.id and s.author_id = v_user
    and c.publication_history_known = true
    and c.ever_published_at is null
    and c.archived_at is null;
  if not found then raise exception 'chapter_not_eligible_for_permanent_deletion'; end if;
  return jsonb_build_object('success', true, 'deleted', true);
end;
$$;

revoke all on function public.gidireads_archive_chapter(uuid) from public, anon;
revoke all on function public.gidireads_restore_archived_chapter(uuid) from public, anon;
revoke all on function public.gidireads_delete_never_published_chapter(uuid) from public, anon;
revoke all on function public.gidireads_track_chapter_publication_history() from public, anon, authenticated;
grant execute on function public.gidireads_archive_chapter(uuid) to authenticated;
grant execute on function public.gidireads_restore_archived_chapter(uuid) to authenticated;
grant execute on function public.gidireads_delete_never_published_chapter(uuid) to authenticated;

commit;
