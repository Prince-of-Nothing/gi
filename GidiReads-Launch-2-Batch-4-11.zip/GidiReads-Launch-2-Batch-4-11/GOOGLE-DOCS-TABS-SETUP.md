# Google Docs import setup for GidiReads

## Current integration

GidiReads uses Google Picker so a writer chooses a specific Google Doc from Drive. The OAuth request uses the narrower `https://www.googleapis.com/auth/drive.file` scope rather than requesting read access to every Google Doc in the writer's account. The app reads the selected document only; it never edits the source document.

Google Picker and the Google Docs API must be enabled in the same Google Cloud project as the OAuth Web Client. The browser API key must be restricted to the GidiReads website and `https://docs.google.com/*`, and to the Google Picker, Google Drive and Google Docs APIs.

## Add the restricted browser API key

Open `google-docs-config.js` and replace the empty value below with the restricted API key created in Google Cloud Credentials:

```js
export const GOOGLE_PICKER_API_KEY = 'PASTE_YOUR_RESTRICTED_BROWSER_API_KEY_HERE';
```

Do not add an OAuth Client Secret or any Supabase service-role/secret key to this file. The Google Picker browser API key is public by design; keep the website and API restrictions enabled in Google Cloud.

The project number is already configured as `761285103283`, matching the numeric prefix of this project's OAuth Client ID.

## Import behaviour

1. Open a story's Story Workspace and choose **Import chapters**.
2. Optionally paste a tab-specific Google Docs link.
3. Tap **Choose from Google Drive** and select the same document in Picker. If a tab-specific link was pasted, GidiReads loads only the tab identified by that link.
4. Choose one or more named tabs and preview them. Each selected tab becomes exactly one draft. Headings inside a tab are not used to split it into extra drafts.
5. Review the titles and content, then save. Nothing is published automatically.

The DOCX, TXT, Markdown and text-based PDF import paths continue to use their existing chapter-heading splitting behaviour.

## OAuth verification note

The `drive.file` scope limits access to files the user explicitly selects or opens with the app. This is a narrower access model, but it does not guarantee that Google will waive OAuth verification or every consent warning. Public external use may still require completing Google's verification process. Test with a separate external test account before announcing Google Docs import as generally available.
