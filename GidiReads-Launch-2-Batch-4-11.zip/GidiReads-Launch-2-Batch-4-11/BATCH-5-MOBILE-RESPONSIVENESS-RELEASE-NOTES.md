# GidiReads — Batch 5 release notes

Base: `GidiReads-Batch-1-and-2-Four-Metric-Release-Admin-Auth-Fix-Batch-3-and-4.zip` (the 5:38 pm November 9, 2026 working base confirmed in the conversation).

## Scope
Full-platform mobile responsiveness audit, with no unrelated feature changes and no new horizontal carousels. Existing intentionally horizontal content sections and table/filter overflow areas were not redesigned in this pass.

## Changes
- Added `mobile-responsiveness.css` as a shared mobile-safety layer and linked it from all 46 HTML pages. It adds viewport-width containment, media sizing, min-width safeguards for common layout containers, wrapping for long text, form-control sizing, mobile modal bounds, safe-area padding for bottom navigation, and reduced-motion support.
- Corrected My Shelf bulk-selection behaviour: selection checkboxes and the bulk toolbar are hidden in the normal view; the novel three-dot menu now offers **Select to Remove from Library**; long-pressing a shelf novel enters selection mode and selects that novel; tapping another shelf card in selection mode toggles its selection; Cancel clears selection mode and hides the controls.
- Bulk removal continues to delete only the signed-in reader's `library_entries` rows. Published story records are not deleted.
- Updated the My Shelf asset query versions to `batch-5` so the new JS/CSS are not masked by the previous cache keys.

## Static verification
- 46 HTML pages parsed; all have a viewport meta tag.
- All 46 pages reference the new shared stylesheet.
- 64 root JavaScript files passed Node module syntax checks.
- 52 root CSS files parsed with no syntax errors.
- No missing local script/stylesheet references detected.
- No duplicate HTML IDs detected.
- No database migrations or database writes were made.
- No deployment was performed.

## Not claimed
A live browser/device visual test was not available in this environment. The shared stylesheet is a platform-wide safety layer; page-specific layouts still need a final preview on actual phone sizes before deployment.
