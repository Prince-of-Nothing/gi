GIDIREADS BUILD 01 — INTEGRATED ACCOUNT HUB (DEVELOPMENT PATCH)

This patch builds on the supplied development ZIP and makes the hub discoverable from existing pages. It is not a production deployment.

FILES INCLUDED
- my-gidireads.html / .js / .css — account hub: Overview, Badges & Achievements, Wallet & Store, Tasks & Rewards.
- account.html — adds a visible My GidiReads button to the existing account editor.
- author.html / author.js — adds My GidiReads to the public profile action row only when the signed-in user is viewing their own profile.
- GIDIREADS-BUILD-01-SCHEMA.sql — proposed database schema; do not run on production.

WHAT IS REAL IN THIS PATCH
- The hub reads the signed-in user's profile and existing story/chapter/reading activity using the current project client.
- The new hub is linked from the existing account editor and from the signed-in user's own public profile.
- The hub does not accept client-side balance changes, payments, gift sends, task claims, or chapter unlocks.
- Wallet values show an em dash until a real wallet row exists; the page will not represent a missing wallet as a genuine zero balance.
- Badge award refresh remains disabled until the SQL has been reviewed and tested in an isolated development database.

IMPORTANT DATABASE LIMITATION
The SQL file is a draft for review, not an instruction to run it now. The connected Supabase project contains real GidiReads data and has no development branch confirmed. A separate Netlify preview does not isolate its database. Do not execute the SQL against production. Some badge criteria and activity table mappings still need schema-level verification before this SQL can be approved.

PREVIEW IN ACODE
1. Extract these files into the same project folder as account.html, author.html, supabaseClient.js, style.css, and the assets folder.
2. Keep the existing files backed up. Replace only the files included in this patch.
3. Open account.html and tap My GidiReads. The hub can be previewed visually; database-only sections will clearly say when setup is missing.
4. Do not upload to the live Netlify site or run the SQL yet.

NOT YET IMPLEMENTED
- Server-verified automatic badge awards and admin badge management.
- Contract applications, signed offer records, and admin review workflow.
- Active task completion/reward claims.
- Payments, gift transactions, paid chapter unlocks, creator earnings, or payouts.
These need separately reviewed backend operations; this patch intentionally does not simulate them.
