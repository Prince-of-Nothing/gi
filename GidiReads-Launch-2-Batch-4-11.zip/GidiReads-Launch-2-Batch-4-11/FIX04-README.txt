GidiReads Profile Fix 04

Overlay these files onto the existing GidiReads project, preserving folder structure. This package contains only changed/new files. It fixes strict profile-picture sizing, moves follower/following to a dedicated people page, and adds robust profile navigation avatar sizing.

Files: author.html, author.js, account.html, account.js, app.js, profile-nav.js, profile-redesign.css, explore.html, library.html, story.html, admin.html, assets/profile-headers/*.webp, people.html, people.js.

Please test on a staging Netlify deploy with a signed-in account before replacing the live site. Supabase policies must permit reading follower relationships and public profile fields.
