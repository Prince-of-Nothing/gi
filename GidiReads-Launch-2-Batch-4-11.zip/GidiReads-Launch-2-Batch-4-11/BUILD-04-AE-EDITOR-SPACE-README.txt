GIDIREADS V5 — BUILD 4: AE EDITOR SPACE

WHAT IS INCLUDED
- A short AE application form with questions about editing/publishing experience, approach, GidiReads knowledge, a sample of feedback and weekly availability.
- Applicants can see their application status. Applications are private and appear in the Admin Dashboard.
- Admins can mark applications In Review, Approved or Rejected and leave an internal note.
- Approval gives the applicant the Acquisitions & Developmental Editor staff role. Pending and rejected applicants cannot open the AE workspace.
- Admins can assign and remove authors. New assignments require an approved AE and an author with an active contract.
- The AE workspace includes Overview, My Authors, Editorial Desk, Author Scouting, Promotions and Performance.
- Assigned authors and contracted stories come from contract and assignment records, not manually typed labels.
- Story Review is a separate read-only page. It shows published chapters only and checks the AE's assignment and active contract on the server.
- AEs can send developmental, chapter and continuity feedback. Authors can read feedback in Authors Studio > Editorial Feedback and reply there. AEs cannot edit or publish the manuscript.
- AEs can record writers they discover, track contact status and keep scouting notes.
- AEs can recommend assigned stories for homepage, Explore, collections, campaigns or author spotlights. Recommendations wait for admin approval.
- Performance counts saved assignments, reviews, scouting leads and promotion decisions. It does not estimate quality or earnings.
- Authors Studio links to the application page and shows the AE Workspace link only for an account with active AE access. Authors also have a separate Editorial Feedback page.
- The Authors Studio Resource Guide now explains applications, role limits, author assignments, read-only reviews, feedback, scouting, promotion requests and performance.

ROLE LIMITS
AEs can support assigned authors, read published chapters, send feedback, scout writers and recommend promotions. They cannot approve or sign contracts, edit published manuscripts, approve earnings or payments, or make final public promotion decisions. Authors decide whether to use feedback.

DATABASE
BUILD-04-AE-EDITOR-SPACE-MIGRATION.sql is additive. For an already migrated deployment, also review BATCH-4-AE-ACCESS-CORRECTIONS.sql after the Build 4, Batch 3 draft-sharing, and Build 6 notification migrations are present. The correction closes AE access when an application returns to In Review, prevents duplicate application decision notifications, and enforces the active contract window on shared-draft and published-review access, and revokes old draft shares when an author assignment is removed. Neither migration is applied by packaging this website. It creates application, assignment, editorial review, scouting and promotion records, with protected RPCs and row-level security. Review it against the deployed schema and apply only after the user's approved V5 deployment. No live database was changed.

IMPORTANT DEPLOYMENT NOTE
The AE application, approval, assignment, review, scouting, promotion and performance actions need the migration before they can work against Supabase. The frontend checks for errors and does not pretend a save succeeded. Authenticated end-to-end testing requires the approved deployment and migration. No deployment, live database changes or migration application occurred during this build.

LOCAL CHECKS
- JavaScript syntax checks passed for all changed and added scripts.
- HTML parsing and local link checks passed for AE pages.
- ZIP integrity and root index.html checks passed.
- SQL was reviewed for the expected objects and protected RPCs, but was not executed against a database.
