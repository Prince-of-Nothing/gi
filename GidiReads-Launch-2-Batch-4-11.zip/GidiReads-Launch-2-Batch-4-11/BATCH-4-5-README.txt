GIDIREADS — BATCH 4 & 5 FRONTEND PATCH

This archive contains changed/new files only. It is not a full-site replacement.
Apply it to the matching GidiReads project folder in Acode, not to a different project version. Back up the folder before copying files over it. Extract the ZIP, then copy the included files into the same root locations in your project, allowing replacement of matching files.

INCLUDED AREAS
- Shared plum/lilac visual system for Wallet, Store, Opportunity Centre, Notifications, Contract Centre, Admin Dashboard, moderation and Authors Studio.
- Wallet: clearer balance breakdown, daily free Echo claim/status card, individual 24-hour expiry wording, gift catalogue artwork/prices, privacy-aware gift-history RPC, and consistent currency display.
- Store: gift artwork and Support Echoes costs, named/anonymous gift sending through the authenticated v2 RPC, no misleading hard-coded Naira package prices, and chapter pricing moved out of Store.
- Authors Studio: chapter pricing panel using the server-side pricing RPC. An accepted creator agreement with the paid-chapters scope is required. Paid purchases remain disabled.
- Opportunity Centre: dynamic opportunity state labels and responsive styling.
- Notifications: System, Comments, Likes, Reviews, Echoes and Collections filters; removes the All filter.
- Shared styling for Contract Centre, Admin Dashboard, Creator Economy Admin and Moderation.

IMPORTANT — TEST STATUS
Static checks passed for the changed pages and root assets: HTML parsing/local references, duplicate IDs, JavaScript syntax (35 root JS files), and CSS parsing (34 root CSS files).

Authenticated end-to-end database testing is NOT complete. The development Supabase project has significant schema drift from production: it lacks the daily Echo tables/RPCs, privacy-aware gift-history and v2 gift RPCs, creator contract tables/RPCs, and some profile/notification columns used by the current production routines. Its private wallet posting routine also differs from production. I did not apply an improvised migration because that could leave the development wallet or contract schema inconsistent. No production writes or database schema changes were made during this review. Browser rendering screenshots could not be run in the current environment.

This means the frontend patch is prepared, but it is not certified as fully live-tested. After the development schema is safely brought up to date, test the authenticated daily claim/cooldown/idempotency, named and anonymous gifts/history privacy, and contract-gated chapter pricing workflows before enabling monetisation.

Payments and payouts remain disabled. Package amounts are illustrative and no currency is implied. Do not enable purchases until a payment provider, supported currencies, server-side payment verification and payout policies are configured.
