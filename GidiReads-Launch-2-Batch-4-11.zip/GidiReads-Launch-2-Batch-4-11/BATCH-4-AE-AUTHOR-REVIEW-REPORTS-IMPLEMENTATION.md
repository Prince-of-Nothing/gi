# Batch 4 — Author reviews, AE reports, performance and authority management

This update adds the author-to-Acquisition-Editor accountability workflow to the existing Batch 4 AE system.

## Included in this project

- `ae-author-feedback.html` / `ae-author-feedback.js`: authors can rate their currently assigned AE, leave/update written feedback, and submit a confidential report about that AE. The existing editorial feedback/reply area remains available on the same page.
- `ae.js`: the AE Performance pane now includes author rating count, average author rating and author report count alongside existing activity measures.
- `moderator.html` / `moderator.js`: a separate Acquisition Editor report queue is available to authorised moderators and admins. Moderators can mark a report under review, actioned or dismissed and record a note. Updates are written to the moderation action log.
- `admin.js`: the AE Applications/Admin area now includes an AE performance summary (author ratings, average rating, editorial reviews, active author assignments and report counts), plus controls to remove AE authority and optionally reassign active contracted authors to another active AE.

## Database changes applied to production Supabase

Project: `mbikuyuhcttkcqpgiihr`

Applied migrations:
- `batch_4_author_ae_reviews_reports`
- `batch_4_admin_ae_authority_management`
- `batch_4_ae_author_feedback_assignment_scope`
- `batch_4_author_ae_assignment_listing_fix`
- `batch_4_remove_legacy_ae_feedback_rpc_overloads`

New tables: `ae_author_feedback`, `ae_author_reports`.

New/updated RPCs: `author_get_assigned_ae`, `author_submit_ae_feedback`, `author_report_ae`, `moderator_get_ae_reports`, `moderator_update_ae_report`, `admin_get_ae_performance`, `admin_manage_ae_authority`, `ae_get_performance`.

The new tables have RLS enabled and direct client table access revoked. Access is mediated by authenticated RPCs that verify author ownership/active assignment, moderator/admin authority, or admin authority as appropriate. Anonymous execution is revoked.

## Important behaviour

- A rating is one per active author–AE assignment and can be updated by that author.
- Ratings do not automatically remove an AE or trigger a bonus.
- Reports enter a separate moderator queue; moderators document review outcomes.
- Admins make the final decision on AE authority and reassignment.
- Removing AE authority deactivates the AE staff role and their active author assignments. If a replacement AE is selected, currently contracted authors are reassigned as part of the same database operation.
- No payment, bonus amount, payout or PSP functionality is enabled by this change.

## Verification performed

- Production database confirms the new feedback/report tables and RPCs exist.
- RPC privilege checks confirm anonymous execution is false and authenticated execution is granted; each RPC performs its own role/ownership check.
- Legacy broad-signature feedback/report RPC overloads were removed.
- Frontend JavaScript syntax checks are run as part of packaging.

Browser-level author, moderator and admin workflow testing still needs to be completed after the updated ZIP is deployed.

## Follow-up verification and safeguards — 8 November 2026

The deployed Batch-4 archive supplied for this pass is the source of truth. The following changes were added on top of it:

- Admins cannot review or approve their own AE application.
- Admins cannot assign themselves as the AE for their own author account.
- Admins cannot use the AE authority-management action on their own AE account or choose themselves as a replacement AE.
- Authors cannot retrieve, rate or report an AE assignment where the author and AE are the same account. An AE who also has admin/moderator privileges cannot inspect or action reports submitted about that same AE account, and is excluded from those report alerts.
- Contract Centre now displays the currently assigned Acquisition Editor and a direct **Review your AE** link when an active assignment exists.
- Authors Studio navigation now labels the entry **Review your AE**.
- AE assignment, AE editorial feedback, author replies, author AE ratings, report receipt, moderator report updates and assignment changes now create in-app system notifications. Report notifications do not expose report details to the AE.
- System-category notifications use the official `assets/gidireads-logo.png` asset and the sender label **GidiReads**, instead of presenting the admin's personal avatar as the platform identity.

Production data correction:
- One active self-assignment was found (`ae_user_id = author_id`) and deactivated.
- Any active draft shares attached to that self-assignment were revoked.
- The author was notified that another approved editor will be assigned when one is available.
- At the time of the check, there were no other active approved AEs available as a replacement. The author's contract was not changed.

Database migrations applied to production: `batch4_ae_conflict_and_feedback_notifications`, `batch4_ae_editorial_feedback_notifications` and `batch4_ae_report_confidentiality_guard`.

Verification scope: database migration application succeeded; the self-assignment count is now zero; frontend JavaScript syntax checks and ZIP integrity checks are performed before packaging. Browser-level end-to-end testing is still not claimed.
