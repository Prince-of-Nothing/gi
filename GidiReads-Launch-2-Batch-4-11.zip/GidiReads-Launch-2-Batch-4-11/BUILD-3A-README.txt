GidiReads V5 — Build 3A: Central Chapter Pricing Engine

This is the complete V5 website package with the central pricing engine work added. It includes all files from the previous Build 2 total package, plus the updated author pricing guide, administrator pricing controls, and a held Supabase migration.

Start here: index.html is at the ZIP root and is the first archive entry.

New files:
- chapter-pricing-admin.js
- chapter-pricing-admin.css
- supabase/migrations/20261102220000_central_chapter_pricing_engine.sql
- BUILD-3A-CENTRAL-PRICING-ENGINE-NOTES.txt

Updated files:
- admin.html
- admin.js
- chapter-pricing.html
- chapter-pricing.js

Pricing guide:
- Non-exclusive: 25, 30, 35, 40, 50, 60 G Coins by increasing chapter word bands.
- Exclusive: 25, 30, 35, 40, 50, 70 G Coins by increasing chapter word bands.
- Manual price limits remain 25–60 for non-exclusive and 25–100 for exclusive.
- Echo-only and uncontracted stories cannot use paid chapter pricing.

Release boundary:
- The migration is included but NOT applied.
- No Supabase or Vercel changes and no deployment were made.
- Payments remain disabled.
- Authenticated database tests must be done after V5 deployment.
