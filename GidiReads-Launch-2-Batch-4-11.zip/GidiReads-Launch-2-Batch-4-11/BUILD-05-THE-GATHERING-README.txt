GIDIREADS V5 — BUILD 5: THE GATHERING (REVISED)

This package updates the existing complete V5 website. index.html remains at the ZIP root. Existing homepage winter/Holiday Hearts work, Authors Studio repairs, and Bulk Chapter Import files are retained.

COMMUNITY EXPERIENCE
- Homepage now has a direct The Gathering navigation link and three working shortcut cards: Discussions, Reading Circles, Weekly Prompts.
- Each shortcut opens the corresponding destination in community.html.
- Community Home, Discussions, Reading Circles, Weekly Prompts, Author's Corner, Community Spotlight, My Community Profile and the restricted Moderation view are connected to the community data layer.
- Discussion creation, replies, following, reporting; circle creation/join/request, member posts and owner milestones; prompt submissions/updates; admin prompt publishing and curated feature publishing; profile editing; report review/dismissal are implemented in the frontend.
- First-visit guided tour highlights destinations with a hand pointer and explanatory notes. Members can skip it, revisit it using Get started, or restart the tour. Completion is remembered in the browser.
- Visual direction: deep plum, violet, indigo, ice blue, teal accents and silver-white text, with responsive layouts.

IMAGE FILES
The following user-owned image paths are wired into the page. The image files are not included and must be added by the owner after extraction:
- assets/the-gathering/gathering-portal.jpg
- assets/the-gathering/gathering-community.jpg
- assets/the-gathering/gathering-reading-circle.jpg
CSS gradient fallbacks remain when images are absent.

DATABASE
Apply BUILD-05-THE-GATHERING-MIGRATION.sql first, then BUILD-05-THE-GATHERING-FINAL-MIGRATION.sql, after deploying the website and reviewing the SQL against the live schema. These migrations have NOT been applied to production in this work. No live database, Vercel deployment, role assignments or external services were changed.

VERIFICATION STATUS
JavaScript syntax and ZIP integrity are checked in the build workspace. A live Supabase/RLS test, browser interaction test, image verification and mobile deployment test remain outstanding until the package is deployed and the two migrations are applied. Do not treat the Gathering as production-live until those checks pass.
